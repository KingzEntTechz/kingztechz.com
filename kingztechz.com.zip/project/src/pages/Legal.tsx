export default function Legal() {
  return (
    <div className="animate-fade-in min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        <h1 className="text-3xl font-bold text-white mb-2">Terms and Conditions</h1>
        <p className="text-gray-400 mb-8">
          Welcome to our website. By accessing or using our services, you agree to be bound by the following terms and conditions. Please read them carefully.
        </p>

        <div className="space-y-6">
          <section className="card p-6">
            <h2 className="text-lg font-bold text-info-500 mb-2">1. Digital Products</h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              All products sold on this website are digital in nature. Once purchased, they will be delivered electronically to the customer's registered email or account download section.
            </p>
          </section>

          <section className="card p-6">
            <h2 className="text-lg font-bold text-accent-500 mb-2">2. No Refund Policy</h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              Due to the nature of digital products, all sales are final. We do not offer refunds, exchanges, or cancellations once the product has been delivered or the download link has been accessed.
            </p>
          </section>

          <section className="card p-6">
            <h2 className="text-lg font-bold text-success-500 mb-2">3. License and Usage</h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              All digital products are sold for personal or commercial use as specified. Redistribution, resale, or unauthorized sharing of our digital content is strictly prohibited.
            </p>
          </section>

          <section className="card p-6">
            <h2 className="text-lg font-bold text-info-500 mb-2">4. Account Responsibility</h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              You are responsible for maintaining the confidentiality of your account and password. We are not liable for any loss or damage arising from your failure to protect your login credentials.
            </p>
          </section>

          <section className="card p-6">
            <h2 className="text-lg font-bold text-accent-500 mb-2">5. Modifications</h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              We reserve the right to update or modify these Terms and Conditions at any time without prior notice. Continued use of our services after any changes shall constitute your consent to such changes.
            </p>
          </section>

          <section className="card p-6">
            <h2 className="text-lg font-bold text-success-500 mb-2">6. Disclaimer</h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              All products are provided "as is" without warranties of any kind, either express or implied. We do not guarantee that our products will meet your expectations or be error-free.
            </p>
          </section>

          <section className="card p-6">
            <h2 className="text-lg font-bold text-info-500 mb-2">7. Governing Law</h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              These terms are governed by the laws of our jurisdiction. Any disputes shall be resolved in the courts of our country or region.
            </p>
          </section>

          <p className="text-center text-gray-500 text-sm pt-4">
            If you have any questions about our terms, please contact us.
          </p>
        </div>
      </div>
    </div>
  );
}
