import { useAuth } from '@/context/AuthContext';
import { Scale } from 'lucide-react';

export default function Footer({ onLegal, onHome }: { onLegal?: () => void; onHome?: () => void }) {
  const { settings, profile } = useAuth();
  const nameParts = profile?.full_name?.trim().split(/\s+/) || [];
  const userName = nameParts[nameParts.length - 1] || '';
  const poweredBy = settings?.footer_text || 'Kingz Techz';

  return (
    <footer className="bg-dark-500/60 border-t border-dark-50 mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <button
          onClick={onLegal}
          className="flex items-center gap-1 text-xs text-gray-500 hover:text-info-500 transition-colors"
        >
          <Scale className="w-3.5 h-3.5" /> Terms and Conditions
        </button>
        <p className="text-sm text-gray-400 text-right leading-relaxed">
          © 2026 {userName && `${userName}. `}Powered by{' '}
          <button type="button" onClick={onHome} className="font-semibold text-info-500 hover:text-info-400 transition-colors">{poweredBy}</button>.
        </p>
      </div>
    </footer>
  );
}
